<?php

 include_once (PUBLIC_PATH.'template/base_end.php');

 mysqli_close($dbConnection);
?>